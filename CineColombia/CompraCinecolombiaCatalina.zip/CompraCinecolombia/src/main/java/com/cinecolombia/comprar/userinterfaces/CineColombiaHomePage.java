package com.cinecolombia.comprar.userinterfaces;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.DefaultUrl;

@DefaultUrl("https:///www.cinecolombia.com/medellin")

public class CineColombiaHomePage extends PageObject {

}
